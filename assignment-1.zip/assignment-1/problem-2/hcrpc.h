#ifndef A4_H
#define A4_H
/*** 
hcrpc.h	Header file for rpcclient.c and rpcserver.c  
***/

#define SERVICENUM	0x2f398499
#define VERSION		1
#define	PROCNUM		1
#define MAXSTRLEN	1024

#endif

