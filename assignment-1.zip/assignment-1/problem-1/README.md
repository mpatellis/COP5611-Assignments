Files in problem 1 can be run using the following steps:

Run make in the problem 1 folder
sudo insmod problem-1.ko to load the module
dmesg to view the module being loaded and the list being created
sudo rmmod problem-1 to remove the module
dmesg to view the log removing it